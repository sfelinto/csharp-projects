﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AspNetMvc5.DAO;
using AspNetMvc5.Filtros;
using AspNetMvc5.Models;
namespace AspNetMvc5.Controllers
{
    [AutorizacaoFilter]
    public class ProdutoController : Controller
    {
        private ProdutosDAO daoProduto = new ProdutosDAO();
        private CategoriasDAO daoCategoria = new CategoriasDAO();
        // GET: Produto
        [Route("produtos", Name = "listaDeProdutos")]
        public ActionResult Index()
        {
            IList<Produto> produtos  = daoProduto.Lista();
            //ViewBag.Produtos = produtos;
            return View(produtos);
        }

        public ActionResult Form()
        {
            IList<CategoriaDoProduto> listaDeCategoriaDoProdutos = daoCategoria.Lista();
            ViewBag.Categorias = listaDeCategoriaDoProdutos;
            ViewBag.Produto = new Produto();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Adiciona(Produto produto)
        {

            int idInformatica = 1;
            if (produto.CategoriaId.Equals(idInformatica) && produto.Preco <= 100)
            {
                ModelState.AddModelError("produto.Invalido", "Informatica com preco abaixo de R$100,00 Reais");
            }

            if (ModelState.IsValid)
            {
                daoProduto.Adiciona(produto);
                return RedirectToAction("Index", "Produto");
            }
            else
            {
                ViewBag.Produto = produto;
                ViewBag.Categorias = daoCategoria.Lista();
                return View("Form");
            }
        }

        [Route("produtos/{id}", Name = "visualizaProduto")]
        public ActionResult Visualiza(int id)
        {
            Produto umProduto = daoProduto.BuscaPorId(id);
            ViewBag.Produto = umProduto;
            return View();
        }

        public ActionResult DecrementaQtd(int id)
        {
            Produto produto = daoProduto.BuscaPorId(id);
            produto.Quantidade--;
            daoProduto.Atualiza(produto);
            return Json(produto);
        }
    }

}