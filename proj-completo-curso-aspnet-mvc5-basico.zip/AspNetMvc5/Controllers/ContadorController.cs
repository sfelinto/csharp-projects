﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AspNetMvc5.Controllers
{
    public class ContadorController : Controller
    {
        // GET: Contador
        public ActionResult Index()
        {
            Object contadorNaSessao = Session["contador"];
            var contador = Convert.ToInt32(contadorNaSessao);
            contador++;
            Session["contador"] = contador;
            return View(contador);
        }
    }
}