﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AspNetMvc5.Models;
using AspNetMvc5.DAO;

namespace AspNetMvc5.Controllers
{
    public class CategoriaController : Controller
    {
        private CategoriasDAO daoCategoria = new CategoriasDAO();

        // GET: Categoria
        [Route("categorias", Name = "listaCategorias")]
        public ActionResult Index()
        {
            //CategoriasDAO dao = new CategoriasDAO();
            IList<CategoriaDoProduto> categorias = daoCategoria.Lista();
            //ViewBag.Categorias = listaCategorias;
            return View(categorias);
        }

        public ActionResult Form()
        {
            ViewBag.Categoria = new CategoriaDoProduto();
            return View();
        }

        [HttpPost]
        public ActionResult Adiciona(CategoriaDoProduto categoria)
        {
            if (ModelState.IsValid)
            {

                daoCategoria.Adiciona(categoria);
                return RedirectToAction("Index", "Categoria");
            }
            else
            {
                ViewBag.Categoria = categoria;
                ViewBag.Categorias = daoCategoria.Lista();
                return View("Form");
            }
        }

        [Route("categorias/{id}", Name = "visualizaCategoria")]
        public ActionResult Visualiza(int id)
        {
            CategoriaDoProduto umaCategoria = daoCategoria.BuscaPorId(id);
            ViewBag.Categoria = umaCategoria;
            return View();
        }
    }
}