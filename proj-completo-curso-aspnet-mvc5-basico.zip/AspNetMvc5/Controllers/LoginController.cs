﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AspNetMvc5.DAO;
using AspNetMvc5.Models;

namespace AspNetMvc5.Controllers
{
    public class LoginController : Controller
    {
        private UsuariosDAO daoUsuario = new UsuariosDAO();

        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Autentica(String login, String senha)
        {
            Usuario usuario = daoUsuario.Busca(login, senha);
            if (usuario != null)
            {
                Session["usuarioLogado"] = usuario;
                return RedirectToAction("Index", "Produto");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
    }
}