﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AspNetMvc5.Models
{
    public class CategoriaDoProduto
    {
        public int Id { get; set; }

        [Required, StringLength(50)]
        public String Nome { get; set; }
        public String Descricao { get; set; }
    }
}