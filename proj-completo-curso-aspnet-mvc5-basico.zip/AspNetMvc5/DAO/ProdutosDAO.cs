﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AspNetMvc5.Models;

namespace AspNetMvc5.DAO
{
    public class ProdutosDAO
    {
        public void Adiciona(Produto produto)
        {
            using (var context = new EstoqueContext())
            {
                context.Produtos.Add(produto);
                context.SaveChanges();
            }
        }

        public IList<Produto> Lista()
        {
            using (var context = new EstoqueContext())
            {
                return context.Produtos.Include("Categoria").ToList();
            }
        }

        public Produto BuscaPorId(int id)
        {
            using (var context = new EstoqueContext())
            {
                return context.Produtos.Include("Categoria").Where(p => p.Id == id).FirstOrDefault();
            }
        }

        public void Atualiza(Produto produto)
        {
            using (var context = new EstoqueContext())
            {
                context.Entry(produto).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
            }
        }
    }
}